# Arunima Vidya Mandir Website

Website for **Arunima Vidya Mandir, Bheemdatta-2, Kanchanpur, Nepal**.

## Files

- `index.html` — main website
- `style.css` — responsive design
- `script.js` — mobile navigation and demo contact form
- `assets/images/school-logo.jpg` — supplied school logo
- `assets/images/school-building.jpg` — supplied school building photo
- `assets/images/` — add additional official school photographs here

## Publish with GitHub Pages

1. Upload these files to your GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the branch containing the website files and the `/ (root)` folder.
5. Save and wait for GitHub Pages to publish the site.

Before publishing, replace placeholder contact information and gallery items with information approved by the school.
